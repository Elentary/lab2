#include "lab_helpers.h"

#include <iostream>

int main() {
  return 0;
}
